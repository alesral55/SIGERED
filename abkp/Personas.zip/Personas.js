import { poolPromise } from './db.js';
import sql from 'mssql';

export function Persona(userInfo) {
    return userInfo + "message: 25";
}

export async function validarUsuario(correo, contrasenia) {
    console.log("entra a validar usuario", correo, contrasenia);
    try {
        // Espera a que la conexión al pool esté lista
        const pool = await poolPromise;
        
        // Crear un objeto request
        const request = pool.request();

        // Asignar parámetros de entrada
        request.input('correo', sql.NVarChar(510), correo);
        request.input('contrasenia', sql.NVarChar(sql.MAX), contrasenia);

        // Asignar parámetros de salida
        request.output('Nombre', sql.NVarChar(200));
        request.output('idRol', sql.Int);
        request.output('accesos', sql.NVarChar(40));
        request.output('cui', sql.NVarChar(30));
        request.output('cambio', sql.Int);

        // Ejecutar el procedimiento almacenado de manera asíncrona
        const result = await request.execute('sp_validarUsuario');
        console.log(result);
            // Verificar si hay resultados en las salidas
    if (!result.output.Nombre || !result.output.idRol) {
        // Si no hay valores, devolver null
        console.log("no existe en la base de datos");
        return null;
      }
        // Retornar los resultados del procedimiento almacenado
        return {
            nombre: result.output.Nombre,
            idRol: result.output.idRol,
            accesos: result.output.accesos,
            cui: result.output.cui,
            requiereCambio: result.output.cambio
        };
    } catch (err) {
        // Manejo de errores
        throw new Error(`Error al validar usuario: ${err.message}`);
    }
}
