import { buildResponse } from '../utils/utils.js';

export const Personas = async(userInfo) =>{

    return userInfo
}