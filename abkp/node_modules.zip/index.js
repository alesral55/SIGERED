// index.js
/*
import { Alumnos } from './Alumnos.js';
import { buildResponse } from './utils/utils.js';
import { Personas} from './Personas.js'
*/
const loginPath = '/login';
const registerPath = '/register';
const healthPath = '/health';

export const handler = async (event) => {
  let response;

  try {
    switch (true) {
      case event.httpMethod === 'GET' && event.path === healthPath:
        response = buildResponse(200, { message: 'Health check OK' });
        break;

      case event.httpMethod === 'POST' && event.path === registerPath:
        const registerBody = JSON.parse(event.body);
        const insertResult = await Alumnos.insertarAlumno(registerBody);
        response = buildResponse(200, { message: `Alumno insertado con éxito. Resultado: ${insertResult}` });
        break;

      case event.httpMethod === 'POST' && event.path === loginPath:
        const loginBody = JSON.parse(event.body);
        //const loginResult = await Alumnos.validarUsuario(loginBody.correo, loginBody.contrasenia);
        const loginResult = await Personas(event.body);

        response = buildResponse(200, loginResult);
        break;

      default:
        response = buildResponse(404, { message: 'Ruta no encontrada' });
    }
  } catch (error) {
    response = buildResponse(500, { message: `Error: ${error.message}` });
  }

  return response;
}
