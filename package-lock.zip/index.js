import { buildResponse } from './utils/utils.js';
import { validarUsuario } from './Personas.js';
import { cambiarContrasenia } from './Personas.js';

const loginPath = '/login';
const registerPath = '/register';
const healthPath = '/health';

export const handler = async (event) => {
  let response;
  console.log("entra al index");
  console.log(event);
  try {
    switch (true) {

      case event.httpMethod === 'GET' && event.path === healthPath:
        response = buildResponse(200, { message: 'Health check OK' });
        break;

      case event.httpMethod === 'POST' && event.path === loginPath:
        const loginBody = JSON.parse(event.body);

        // Agregar await para esperar a la resolución de la promesa
        const loginResult = await validarUsuario(loginBody.correo, loginBody.contrasenia);

        console.log(loginResult, "respuesta de la validación");

        // Verificar si `loginResult` es null o no
        if (loginResult) {
          response = buildResponse(200, loginResult);
        } else {
          response = buildResponse(200, { message: 'Credenciales incorrectas' });
        }

        break;
        case event.httpMethod === 'PUT' && event.path === loginPath:
          const loginBodyP = JSON.parse(event.body);
  
          // Agregar await para esperar a la resolución de la promesa
          const loginResultP = await cambiarContrasenia(loginBodyP.cui, loginBodyP.contraseniaActual, loginBodyP.nuevaContrasenia, loginBodyP.tkn);
  
          console.log(loginResultP, "respuesta de la validación");
  
          // Verificar si `loginResult` es null o no
          if (loginResultP) {
            response = buildResponse(200, loginResultP);
          } else {
            response = buildResponse(200, { message: 'Credenciales incorrectas' });
          }
  
          break;

      default:
        response = buildResponse(404, { message: 'Ruta no encontrada' });
    }
  } catch (error) {
    response = buildResponse(500, { message: `Error: ${error.message}` });
  }

  return response;
}
