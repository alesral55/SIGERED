import { poolPromise } from './db.js';
import sql from 'mssql';
import { generateToken } from './utils/auth.js';
import { verifyToken } from './utils/auth.js';
import bcrypt from 'bcryptjs';

export async function validarUsuario(correo, contrasenia) {
    console.log("Validando usuario:", correo);

    try {
        const pool = await poolPromise;
        const request = pool.request();

        // Parámetros de entrada
        request.input('correo', sql.NVarChar(510), correo);

        // Parámetros de salida
        request.output('contrasenia', sql.NVarChar(sql.MAX));
        request.output('Nombre', sql.NVarChar(200));
        request.output('idRol', sql.Int);
        request.output('accesos', sql.NVarChar(40));
        request.output('cui', sql.NVarChar(30));
        request.output('cambio', sql.Int);

        // Ejecutar el procedimiento almacenado
        const result = await request.execute('sp_validarUsuario');
        console.log(result);

        // Verificar que la contraseña no sea null y comparar con bcrypt
        const passwordDB = result.output.contrasenia?.trim();
        const passwordMatches = bcrypt.compareSync(contrasenia.trim(), passwordDB);

        if (!passwordMatches) {
            console.log("Contraseña incorrecta");
            return null;
        }

        if (!result.output.Nombre || !result.output.idRol) {
            console.log("El usuario no existe en la base de datos");
            return null;
        }

        const userTkn = {
            cui: result.output.cui,
            nombre: result.output.Nombre,
        };

        const token = generateToken(userTkn);

        return {
            nombre: result.output.Nombre,
            idRol: result.output.idRol,
            accesos: result.output.accesos,
            cui: result.output.cui,
            requiereCambio: result.output.cambio,
            token: token,
        };

    } catch (err) {
        throw new Error(`Error al validar usuario: ${err.message}`);
    }
}

//          CAMBIO DE CONTRASENIA

export async function cambiarContrasenia(cui, contraseniaActual, nuevaContrasenia, tkn) {
    console.log("Iniciando el cambio de contraseña para CUI:", cui);

    console.log(tkn);
    // Verificar el token (esperar a que la promesa se resuelva)
    const verification = verifyToken(cui, tkn);
    console.log(verification);
    if (verification.verified== false) {
        return util.buildResponse(401, verification);
    }

    console.log('El token es válido');

    try {
        // Conectar al pool de la base de datos
        const pool = await poolPromise;
        const request = pool.request();

        // 1. Obtener la contraseña actual de la base de datos
        request.input('cui', sql.NVarChar(30), cui);
        const result = await request.execute('sp_obtenerContrasenia');

        const contraseniaBD = result.recordset[0]?.contrasenia?.trim();
        if (!contraseniaBD) {
            console.log("No se encontró la contraseña en la base de datos");
            return {
                status: 404,
                message: "Usuario no encontrado"
            };
        }

        // 2. Comparar la contraseña actual con la almacenada en la base de datos
        const passwordMatches = bcrypt.compareSync(contraseniaActual.trim(), contraseniaBD);
        if (!passwordMatches) {
            console.log("La contraseña actual es incorrecta");
            return {
                status: 400,
                message: "La contraseña actual no coincide"
            };
        }

        // 3. Encriptar la nueva contraseña
        const nuevaContraseniaEncriptada = bcrypt.hashSync(nuevaContrasenia.trim(), 10);

        // 4. Actualizar la contraseña en la base de datos
        const updateRequest = pool.request();
        updateRequest.input('cui', sql.NVarChar(30), cui);
        updateRequest.input('contrasenia', sql.NVarChar(sql.MAX), nuevaContraseniaEncriptada);
        updateRequest.output('resultado', sql.Int);

        const updateResult = await updateRequest.execute('sp_cambiarContrasenia');
        const resultado = updateResult.output.resultado;

        if (resultado === 1) {
            return {
                status: 200,
                code: 1,
                message: "Contraseña actualizada correctamente",
                token: tkn  // Devuelve el mismo token
            };
        } else {
            return {
                status: 500,
                message: "Error al actualizar la contraseña"
            };
        }

    } catch (err) {
        console.error(`Error al cambiar la contraseña: ${err.message}`);
        throw new Error(`Error al cambiar la contraseña: ${err.message}`);
    }
}
