       /*
       // Deshabilitar clic derecho
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        }, false);
        
        // Intento de bloquear la consola
        (function() {
            var _z = console;
            Object.defineProperty(window, "console", {
                get: function() {
                    return _z;
                },
                set: function(val) {
                    _z = val;
                }
            });
        })();*/

        function Login() {
            const Correo = document.getElementById('Correo').value;
            const Contrasenia = document.getElementById('Contrasenia').value;
        
            if (Correo === '') {
                document.getElementById('CorreoMsg').style.display = 'block';
                return;
            }
            if (Contrasenia === '') {
                document.getElementById('ContraseniaMsg').style.display = 'block';
                return;
            }
        
            // Encriptar la contraseña antes de enviarla
            const encryptedPassword = CryptoJS.AES.encrypt(Contrasenia, 'AELMVCPIWTPCP').toString();
        
            // Ahora puedes enviar la contraseña encriptada
            alert('Contraseña encriptada: ' + encryptedPassword + '\nCorreo: ' + Correo);

            fetch('https://kb8nwnnugk.execute-api.us-east-1.amazonaws.com/Produccion/login', {
                method: 'POST',
                body: JSON.stringify({
                    correo: Correo,
                    contrasenia: Contrasenia
                }),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(function(respuesta){
                if(respuesta.ok){
                    return respuesta.json();
                }
                throw new Error('Red no OK');
            })
            .then(function(datos){
                alert(JSON.stringify(datos)); // Asegúrate de convertir el objeto en una cadena
            })
            .catch(function(error){
                console.error('Error:', error);
            });
            
        }