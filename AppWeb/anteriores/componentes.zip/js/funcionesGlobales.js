const path = 'http://localhost:3000/'

document.addEventListener('DOMContentLoaded', function () {
    let nombreUsuario = sessionStorage.getItem('nombre');

    fetch('/componentes/nav.html')
    .then(response => response.text())
    .then(data => {
        document.getElementById('nav-content').innerHTML = data;
        if (nombreUsuario) {
            let userDropdown = document.getElementById('userDropdown');
            userDropdown.innerText = nombreUsuario;
            let dropdowns = document.querySelectorAll('.dropdown-toggle')
            dropdowns.forEach((dd) => {
                dd.addEventListener('click', function (e) {
                    var el = this.nextElementSibling
                    el.style.display = el.style.display === 'block' ? 'none' : 'block'
                })
            })
            cargarInicio();
        } else {
            window.location.href = '/index.html';
        }
    
    })
    .catch(error => console.error('Error al cargar el header:', error));
   
});


function logout() {
    // Eliminar todas las variables de sessionStorage
    sessionStorage.clear();
    // Redirigir al usuario a la página de login
    window.location.href = '/index.html';
}

function compararPWD() {
    const Incorrect = document.getElementById('Incorrect')
    const contraseniaActual = document.getElementById('contraseniaActual').value
    const nuevaContrasenia = document.getElementById('nuevaContrasenia').value
    const confirmarContrasenia = document.getElementById('confirmarContrasenia').value
    if (!contraseniaActual || !confirmarContrasenia || !nuevaContrasenia) {
        Incorrect.style.display = 'block'
        Incorrect.innerHTML = 'Debe completar todos los campos'
        return
    }
    if (nuevaContrasenia === confirmarContrasenia) {
        cambiarContrasenia(nuevaContrasenia, contraseniaActual)
    }
    else {

        Incorrect.style.display = 'block'
        Incorrect.innerHTML = 'Las contrase;as no conciden'
        return
    }
}

function cambiarContrasenia(nuevaContrasenia, contraseniaActual) {
    const cui = sessionStorage.getItem('cui')
    const token = sessionStorage.getItem('token')
    fetch('http://localhost:3000/login', {
        method: 'PUT',
        body: JSON.stringify({
            cui: cui,
            contraseniaActual: contraseniaActual,
            nuevaContrasenia: nuevaContrasenia,
            tkn: token
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(function (respuesta) {
            if (respuesta.ok) {
                return respuesta.json();
            }
        })
        .then(function (datos) {
            if (datos.code == 1) {
                ASucces(datos.message)
            }

        })

}



function ASucces(mensaje) {
    Swal.fire(
        'Success',
        mensaje,
        'success'
    )
}

function AError(mensaje) {
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: mensaje,
    });
}

function AWarning(mensaje) {
    Swal.fire({
        icon: 'warning',
        title: 'Atencion!!!',
        text: mensaje,
    });
}


function CalendarioPreV(titulo, contenido, eventoId) {
    Swal.fire({
        icon: '',
        title: titulo,
        html: `${contenido } <br /><br /><a href="/Alumnos/ApartadoTarea?tarea=${eventoId}" class="btn btn-primary">Ir al enlace</a>`,
            showConfirmButton: false,
            showCancelButton: false
        
    });
}
