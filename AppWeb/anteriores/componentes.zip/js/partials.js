
function cargarInicio() {
    const cambio = sessionStorage.getItem('requiereCambio')
    if (cambio == 1) {
        cargarFormulario(60)
    }
    else {
        const rol = sessionStorage.getItem('idRol')
        if (rol == 2) {
            document.getElementById('liAlumnos').style.display = 'none';
            document.getElementById('liMantenimiento').style.display = 'none';
            document.getElementById('liDocentes').style.display = 'block';
            document.getElementById('liAdministracion').style.display = 'none';
            cargarFormulario(30)
        }
        if (rol == 3) {
            document.getElementById('liAlumnos').style.display = 'block';
            document.getElementById('liMantenimiento').style.display = 'none';
            document.getElementById('liDocentes').style.display = 'none';
            document.getElementById('liAdministracion').style.display = 'none';
            cargarFormulario(20)
        }
        if (rol == 1) {
            cargarFormulario(40)
        }

    }

}

function cargarFormulario(direccion) {
    let url
    let src
    switch (direccion) {
        case 1:
            url = '/componentes/inicioAlumnos.html'
            break;
        case 20:
            url = '/componentes/inicioAlumnos.html'
            break;
        case 30:
            url = '/componentes/inicioDocentes.html'
            break;
        case 40:
            url = '/componentes/inicioAdministracion.html'
            break;
            case 50:
                url = '/componentes/inicioMantenimiento.html'
                break;
                case 51:
                    url = '/Mantenimiento/nuevoDocente.html'
                    src = '/js/Mantenimiento/nuevoUsuario.js'
                    break;
                    case 52:
                        url = '/Mantenimiento/actualizarDocente.html'
                        src = '/js/Mantenimiento/nuevoUsuario.js'
                        break;
        case 60:
            url = '/usuario/cambiarContrasenia.html'
            break;
        default:
            alert('No existe la ruta')
            return
    }

    fetch(url)
        .then(response => response.text())
        .then(data => {
            document.getElementById('body-content').innerHTML = data;
            //eliminar y agregar el nuevo script
            $('#partialScript').remove();
            if(src){
                let script = document.createElement('script');
                script.id = "partialScript";
                script.src = src
                document.body.appendChild(script);
            }

        })
        .catch(error => console.log('Error:', error));
}
