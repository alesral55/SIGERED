function ASucces(mensaje) {
    Swal.fire(
        'Success',
        mensaje,
        'success'
    )
}

function AError(mensaje) {
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: mensaje,
    });
}

function AWarning(mensaje) {
    Swal.fire({
        icon: 'warning',
        title: 'Atencion!!!',
        text: mensaje,
    });
}


function CalendarioPreV(titulo, contenido, eventoId) {
    Swal.fire({
        icon: '',
        title: titulo,
        html: `${contenido } <br /><br /><a href="/Alumnos/ApartadoTarea?tarea=${eventoId}" class="btn btn-primary">Ir al enlace</a>`,
            showConfirmButton: false,
            showCancelButton: false
        
    });
}
