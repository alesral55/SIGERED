

document.getElementById('nuevoUsuario').addEventListener('click', function() {
    const form = document.getElementById('formI');
    const formData = new FormData(form);
    return
    fetch('/ruta/tu-api', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Aquí puedes manejar la respuesta de éxito
    })
    .catch((error) => {
        console.error('Error:', error);
        // Aquí puedes manejar el error
    });
});