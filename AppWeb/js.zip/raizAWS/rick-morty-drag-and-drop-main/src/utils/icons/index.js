
import Verano from "../icons/svg/verano.svg"
import Morty from "../icons/svg/morty.svg"
import Jerry from "../icons/svg/jerry.svg"
import Beth from "../icons/svg/beth.svg"
import Rick from "../icons/svg/rick.svg"

export { 
    Morty,
    Verano,
    Jerry,
    Beth,
    Rick
}
